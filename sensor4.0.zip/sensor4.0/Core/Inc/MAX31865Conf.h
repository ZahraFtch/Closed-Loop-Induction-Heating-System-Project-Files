#ifndef _MAX31865CONF_H
#define _MAX31865CONF_H

#define _MAX31865_USE_FREERTOS  0

#define _MAX31865_RREF      430.0f
#define _MAX31865_RNOMINAL  100.0f

#endif
